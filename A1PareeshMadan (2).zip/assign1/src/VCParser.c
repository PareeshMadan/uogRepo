//Name: Pareesh Madan
//Student ID: 1271446
//Email: madanp@uoguelph.ca

#include "VCParser.h"
#include "LinkedListAPI.h"
#include <stdbool.h>
#include <string.h>

//strdup
char* strdup(const char* str);

//prototype
VCardErrorCode readBegin(FILE* fp);
VCardErrorCode readProperty(FILE* fp, Card* card, bool* end);


VCardErrorCode createCard(char* fileName, Card** obj){
    VCardErrorCode err;
    if(fileName == NULL){
        return INV_FILE;
    }


    FILE * fp = fopen(fileName, "r");
    if(fp == NULL){
        return INV_FILE;
    }else{

        //temp vCard
        Card* temp = malloc(sizeof(Card));

        temp->fn = NULL;
        temp->optionalProperties = initializeList(propertyToString, deleteProperty, compareProperties);
        temp->birthday = NULL;
        temp->anniversary = NULL;

        bool valid = true;
        bool end = false;
        bool start = false;

        VCardErrorCode error;
        while(valid == true && end == false){
            if (start == false){
                error = readBegin(fp);

                if(error != OK){
                    fclose(fp);
                    deleteCard(temp);
                    *obj = NULL;
                    return error;
                }

                printf("Beginning of vCard read\n");
                start = true;
            }

            // parse vCard
            err = readProperty(fp, temp, &end);

            if(err != OK){
                fclose(fp);
                deleteCard(temp);
                *obj = NULL;
                return err;
            }

            // end of vCard
            if (end == true) {
                break;
            }
        }
        fclose(fp);
        
        *obj = temp;
        return err;

    }

    
    return OK;


}


void deleteDate(void* toBeDeleted){
    //check if date is null
    if (toBeDeleted == NULL){
        return;
    }else{
        DateTime *date = (DateTime*)toBeDeleted;
        if(date->date != NULL){
            free(date->date);
        }
        if(date->time != NULL){
            free(date->time);
        }
        if(date->text != NULL){
            free(date->text);
        }
        free(date);
    }
}

void deleteProperty(void* toBeDeleted){
    //delete the property
    if (toBeDeleted == NULL){
        return;
    }else{

        Property* prop = (Property*)toBeDeleted;

        if(prop->name != NULL){
            free(prop->name);
        }
        if(prop->group != NULL){
            free(prop->group);
        }
        if(prop->parameters != NULL){
            freeList(prop->parameters);
        }
        if(prop->values != NULL){
            freeList(prop->values);
        }
        free(prop);
    }
}


void deleteParameter(void* toBeDeleted){
    //delete the parameter

    if (toBeDeleted == NULL){
        return;
    }else{
        Parameter* param = (Parameter*)toBeDeleted;
        if(param->name != NULL){
            free(param->name);
        }
        if(param->value != NULL){
            free(param->value);
        }
        free(param);
    }


}

void deleteValue(void* toBeDeleted){
    
    //check if value is null
    if (toBeDeleted == NULL){
        return;
    }else{
        char *temp = (char*)toBeDeleted;
        if(temp != NULL){
            free(temp);
        }
    }
}


void deleteCard(Card* obj){

    if (obj == NULL){
        return;
    }else{
        printf("Successfully deleted card\n"); 
        //delete all properities, parameters, and values
        if(obj->fn != NULL){
            deleteProperty(obj->fn);
        }
        if(obj->optionalProperties != NULL){
            freeList(obj->optionalProperties);
        }
        
        if(obj->birthday != NULL){
            deleteDate(obj->birthday);
        }
        if(obj->anniversary != NULL){
            deleteDate(obj->anniversary);
        }
        free(obj);

    }


}


//dateToString
char* dateToString(void* date){
    //printf("Date is %s\n", date);
    if (date == NULL) return strdup("");

    DateTime *dateTime = (DateTime*)date;
    char *d, *time, *text;

    if (dateTime->date) {
        d = dateTime->date;
    } else {
        d = "";
    }

    if (dateTime->time) {
        time = dateTime->time;
    } else {
        time = "";
    }

    if (dateTime->text) {
        text = dateTime->text;
    } else {
        text = "";
    }
    bool UTC = dateTime->UTC;
    bool isText = dateTime->isText;

    size_t len = strlen(d) + strlen(time) + strlen(text) + 40;
    char *temp = malloc(len);
    if (!temp) return NULL;
    sprintf(temp, "\nDate: %s\nTime: %s\nText: %s\nUTC: %d\nIsText: %d\n", d, time, text, UTC, isText);
    
    return temp;
}

char* valueToString(void* val){
    char *value;
    char *temp;

    if (val == NULL){
        return "";
    }else{

        value = (char*)val;
        temp = (char*)malloc(sizeof(char)*(strlen(value)+2));
        sprintf(temp, "%s ", value);
        
    }
    return temp;
}


char* parameterToString(void* param){

    if (param == NULL){
        return strdup("");
    }
    Parameter *parameter = (Parameter*)param;
    char *name;
    char *value;
    if (parameter->name != NULL){
        name = parameter->name;
    }else{
        name = "";
    }
    if (parameter->value != NULL){
        value = parameter->value;
    }else{
        value = "";
    }

    size_t len = strlen(name) + strlen(value) + 20;
    char *temp = malloc(len);
    if (!temp) return NULL;
    sprintf(temp, "Name: %s Value: %s ", name, value);
    
    return temp;
}

char* propertyToString(void* prop){
    if (prop == NULL){
        return strdup("");
    }
    Property *property = (Property*)prop;

    char *name;
    char *tempGroup;

    if (property->name != NULL){
        name = property->name;
    }else{
        name = "";
    }
    if (property->group != NULL){
        tempGroup = property->group;
    }else{
        tempGroup = "";
    }
    char *param;
    if (property->parameters) {
        param = toString(property->parameters);
    } else {
        param = strdup("");
    }

    char *val;
    if (property->values) {
        val = toString(property->values);
    } else {
        val = strdup("");
    }

    size_t len = strlen(name) + strlen(tempGroup) + strlen(param) + strlen(val) + 50;
    char *temp = malloc(len);
    if (!temp) return NULL;
    snprintf(temp, len, "\nName: %s\nGroup: %s\nParameters: %s\nValues: %s\n", name, tempGroup, param, val);

    free(param);
    free(val);
    return temp;

}

char* cardToString(const Card* obj){
    if (obj == NULL) {
        return strdup("");
    }

    char *fn = propertyToString(obj->fn);
    char *birthday = dateToString(obj->birthday);
    char *anniversary = dateToString(obj->anniversary);
    char *optionalProperties = toString(obj->optionalProperties);
    
    size_t len = strlen(fn) + strlen(optionalProperties) + strlen(birthday) + strlen(anniversary) + 100;
    char *temp = malloc(len);
    if (!temp) {
        free(fn);
        free(birthday);
        free(anniversary);
        free(optionalProperties);
        return NULL;
    }

    snprintf(temp, len, "\nFN:\n %s\nBirthday:\n%s\nAnniversary:\n%s\nOptional Properties:\n%s", fn, birthday, anniversary, optionalProperties);

    free(fn);
    free(birthday);
    free(anniversary);
    free(optionalProperties); // Fix: Ensure freeing memory after use
    return temp;
}

int compareProperties(const void* first,const void* second){
    return 0;
}



int compareParameters(const void* first,const void* second){
    return 0;
}



int compareValues(const void* first,const void* second){
    return 0;
}

char* errorToString(VCardErrorCode err){
    char *error;

    switch(err){
        case OK:
            error = malloc(sizeof(char)*3);
            sprintf(error, "OK");
            return error;
        case INV_FILE:
            error = malloc(sizeof(char)*13);
            sprintf(error, "Invalid File");
            return error;
        case INV_CARD:
            error = malloc(sizeof(char)*13);
            sprintf(error, "Invalid Card");
            return error;
        case INV_PROP:
            error = malloc(sizeof(char)*17);
            sprintf(error, "Invalid Property");
            return error;
        case INV_DT:
            error = malloc(sizeof(char)*13);
            sprintf(error, "Invalid Date");
            return error;
        case WRITE_ERROR:
            error = malloc(sizeof(char)*13);
            sprintf(error, "Write Error");
            return error;
        case OTHER_ERROR:
            error = malloc(sizeof(char)*13);
            sprintf(error, "Other Error");
            return error;
        default:
            error = malloc(sizeof(char)*19);
            sprintf(error, "Invalid vCard code"); 
            return error;
    }

}

