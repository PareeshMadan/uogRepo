//Name: Pareesh Madan
//Student ID: 1271446
//Email: madanp@uoguelph.ca

#include "VCParser.h"
#include "LinkedListAPI.h"


int main(){

    Card * card = NULL;
    VCardErrorCode err = createCard("testCard.vcf", &card);

    char * str = cardToString(card);
    printf("%s\n", str);
    free(str);

    deleteCard(card);
    

    char * errStr = errorToString(err);
    printf("Error is %s\n", errStr);
    free(errStr);

    return 0;
}