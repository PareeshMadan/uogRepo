//Name: Pareesh Madan
//Student ID: 1271446
//Email: madanp@uoguelph.ca

//include files
#include <VCParser.h>
#include "LinkedListAPI.h"

//prototype
char* strdup(const char* str);
int strcasecmp(const char *string1, const char *string2);

//read the beginning of the vCard
VCardErrorCode readBegin(FILE* fp){
    //read the first two lines
    char line[1024];
    fgets(line, 1024, fp);
    line[strlen(line)-2] = '\0';    

    //check if first line is BEGIN:VCARD
    printf("%s\n", line);
    if (strcmp(line, "BEGIN:VCARD") != 0){
        printf("%d\n", strcmp(line, "BEGIN:VCARD"));
        return INV_CARD;
    }

    fgets(line, 1024, fp);
    line[strlen(line)-2] = '\0';
    printf("%s\n", line);
    //check if second line is VERSION:4.0
    if (strcmp(line, "VERSION:4.0") != 0){
        return INV_CARD;
    }
    
    return OK;
}



//read property function
VCardErrorCode readProperty(FILE* fp, Card* card, bool* end){
    Property * prop = malloc(sizeof(Property));
    if (!prop){
        return OTHER_ERROR;
    }
    if(fp == NULL){
        deleteProperty(prop);
        return INV_FILE;
    }

    //initialize linked lists for parameters and values
    prop->name = NULL;
    prop->group = malloc(sizeof(char)*1);
    if (!prop->group) {
        deleteProperty(prop);
        return OTHER_ERROR;
    }
    strcpy(prop->group, "");
 
    prop->parameters = initializeList(parameterToString, deleteParameter, compareParameters);   
    if (!prop->parameters) {
        deleteProperty(prop);
        return OTHER_ERROR;
    }
    prop->values = initializeList(valueToString, deleteValue, compareValues);
    if (!prop->values) {
        deleteProperty(prop);
        return OTHER_ERROR;
    }

    char line[1024];

    //read the first line of the property
    bool fnFilled = false;
    bool bdayFilled = false;
    bool annFilled = false;
    while (fgets(line, 1024, fp) != NULL){

        if (line[0] == ':' || line[0] == '.'){
            deleteProperty(prop);
            return INV_PROP;
        }

        //printf("%s\n", line);
        line[strlen(line)-2] = '\0';

        //if line is greater than 75 octets return error
        if (strlen(line) > 75){
            deleteProperty(prop);
            return INV_PROP;
        }

        // Check for folded lines
        int nextChar;
        while ((nextChar = fgetc(fp)) == ' ' || nextChar == '\t') {
            char nextLine[1024];
            if (fgets(nextLine, sizeof(nextLine), fp) == NULL) {
                break;
            }
            // Remove newline from the folded line
            nextLine[strcspn(nextLine, "\r\n")] = '\0';
            // Append to the current line
            strcat(line, nextLine);
        }
        //unget the next character
        if (nextChar != EOF) {
            ungetc(nextChar, fp);
        }

            
        printf("%s\n", line);
        
        //check if line is end of vCard
        if (strcmp(line, "END:VCARD") == 0){
            *end = true;
            deleteProperty(prop);
            return OK;
        }

        

        else{

            
            //split the line into name and value
            char* token = strtok(line, ":");
            if (token == NULL){
                continue;
            }
            if (prop->name != NULL) {
                free(prop->name);
            }
            prop->name = malloc (sizeof(char)*(strlen(token)+1));

            strcpy(prop->name, token);
            printf("%s\n", prop->name);
            
            //get rest of the line
            token = strtok(NULL, "");

            //check for empty parameters
            char valCopy[1024];
            strcpy(valCopy, token);
            char *t = valCopy;
            int count = 0;
            while((t = strstr(t, ";;"))) {
                count++;
                t++;
            }
            
            
            //if the property name contains a ; then parse the parameters
            if (strchr(prop->name, ';') != NULL){
                //if prop name doesn't contain an equal sign
                if (strchr(prop->name, '=') == NULL){
                    deleteProperty(prop);
                    return INV_PROP;
                }
                //find the first semicolon and split the property name and parameters
                char* paramStart = strchr(prop->name, ';');
                *paramStart = '\0';
                paramStart++;
                char* paramToken = strtok(paramStart, ";");
                while (paramToken != NULL) {
                    char* equalSign = strchr(paramToken, '=');
                    if (equalSign) {

                        *equalSign = '\0';  // Split name and value
                        equalSign++;
                        Parameter* param = malloc(sizeof(Parameter));
                        param->name = malloc(sizeof(char)*(strlen(paramToken)+1));
                        strcpy(param->name, paramToken);
                        printf("%s\n", param->name);
                        param->value = malloc(sizeof(char)*(strlen(equalSign)+1));
                        strcpy(param->value, equalSign);
                        
                        insertBack(prop->parameters, param);
                    }
                    paramToken = strtok(NULL, ";");
                }
                
            }
            // Find the first dot and split the property name and group
            char* dot = strchr(prop->name, '.');
            if (dot != NULL) {
                size_t groupLen = dot - prop->name;
                prop->group = realloc(prop->group, sizeof(char)*(groupLen + 1));
                strncpy(prop->group, prop->name, groupLen);
                prop->group[groupLen] = '\0';
                memmove(prop->name, dot + 1, strlen(dot));
            }else{
                //set group to empty
                strcpy(prop->group, "");
            }

            if (strcasecmp(prop->name, "FN") == 0 && fnFilled == false){
                card->fn = malloc(sizeof(Property));
                card->fn->name = malloc(sizeof(char)*(strlen(prop->name)+1));
                strcpy(card->fn->name, prop->name);
                card->fn->group = malloc(sizeof(char)*(strlen(prop->group)+1));
                strcpy(card->fn->group, prop->group);
                card->fn->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
                card->fn->values = initializeList(valueToString, deleteValue, compareValues);

                char *temp = malloc(sizeof(char)*(strlen(token)+1));
                strcpy(temp, token);

                fnFilled = true;

                insertBack(card->fn->values, temp);  // Store FN value
            
            }else if(strcasecmp(prop->name, "N") == 0){
                //store N property inside card  
                Property *n = malloc(sizeof(Property));
                n->name = malloc(sizeof(char)*(strlen(prop->name)+1));
                strcpy(n->name, prop->name);
                n->group = malloc(sizeof(char)*(strlen(prop->group)+1));
                strcpy(n->group, prop->group);
                n->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
                n->values = initializeList(valueToString, deleteValue, compareValues);
                //split token into values based on ;
                token = strtok(token, ";");
                while (token != NULL){
                    char *temp = malloc(sizeof(char)*(strlen(token)+1));
                    strcpy(temp, token);
                    
            
                    insertBack(n->values, temp);  // Store N value


                    token = strtok(NULL, ";");
                }

                for (int i = 0; i < count; i++){
                    char* insert = malloc(sizeof(char)*1);
                    strcpy(insert, "");
                    insertBack(n->values, insert);
                }

                insertBack(card->optionalProperties, n); // Store other properties
            }else if (strcasecmp(prop->name, "BDAY") == 0 && bdayFilled == false){
                DateTime *dateTime = malloc(sizeof(DateTime));

                // Initialize default values
                dateTime->UTC = false;
                dateTime->isText = false;
                dateTime->date = malloc(sizeof(char)*1);
                strcpy(dateTime->date, "");
                dateTime->time = malloc(sizeof(char)*1);
                strcpy(dateTime->time, "");
                dateTime->text = malloc(sizeof(char)*1);
                strcpy(dateTime->text, "");

                // Check if BDAY has parameters
                bool isTextFormat = false;
                ListIterator iter = createIterator(prop->parameters);
                void *elem;

                bdayFilled = true;

                while ((elem = nextElement(&iter)) != NULL) {
                    Parameter *param = (Parameter *)elem;
                    if (strcmp(param->name, "VALUE") == 0 && strcmp(param->value, "text") == 0) {
                        isTextFormat = true;
                        break;
                    }
                }

                // Process BDAY value
                if (isTextFormat) {
                    dateTime->isText = true;
                    dateTime->text = realloc(dateTime->text,(strlen(token) + 1));  // Store the full text value
                    strcpy(dateTime->text, token);
                } else {
                    //bool hasTime = false;
                    bool isUTC = false;

                    if (token[strlen(token) - 1] == 'Z') {
                        isUTC = true;
                    }
                    

                    char *timePart = strstr(token, "T");
                    if (timePart) {
                        //hasTime = true;
                        *timePart = '\0';  // Split date and time
                        timePart++;

                        dateTime->time = realloc(dateTime->time, strlen(timePart) + 1);  // Store the time value
                        strcpy(dateTime->time, timePart);
                    }

                    dateTime->date = realloc(dateTime->date, strlen(token) + 1);  // Store the date value
                    strcpy(dateTime->date, token);

                    dateTime->UTC = isUTC;
                }

                // Assign to the vCard structure
                card->birthday = dateTime;

                
                
            }else if (strcasecmp(prop->name, "ANNIVERSARY") == 0 && annFilled == false){ 
                DateTime *anniversary = malloc(sizeof(DateTime));

                annFilled = true;
                // Initialize default values
                anniversary->UTC = false;
                anniversary->isText = false;
                anniversary->date = malloc(sizeof(char)*1);
                strcpy(anniversary->date, "");
                anniversary->time = malloc(sizeof(char)*1);
                strcpy(anniversary->time, "");
                anniversary->text = malloc(sizeof(char)*1);
                strcpy(anniversary->text, "");

                // Check if ann has parameters
                bool isTextFormat = false;
                ListIterator iter = createIterator(prop->parameters);
                void *elem;

                while ((elem = nextElement(&iter)) != NULL) {
                    Parameter *param = (Parameter *)elem;
                    if (strcmp(param->name, "VALUE") == 0 && strcmp(param->value, "text") == 0) {
                        isTextFormat = true;
                        break;
                    }
                }

                // Process BDAY value
                if (isTextFormat) { 
                    anniversary->isText = true;
                    anniversary->text = realloc(anniversary->text, (strlen(token) + 1));  // Store the full text value
                    strcpy(anniversary->text, token);
                } else {
                    //bool hasTime = false;
                    bool isUTC = false;

                    if (token[strlen(token) - 1] == 'Z') {
                        isUTC = true;
                    }

                    char *timePart = strstr(token, "T");
                    if (timePart) {
                        *timePart = '\0';  // Split date and time
                        timePart++;

                        anniversary->time = realloc(anniversary->time, strlen(timePart) + 1);  // Store the time value
                        strcpy(anniversary->time, timePart);
                    }

                    anniversary->date = realloc(anniversary->date, (strlen(token) + 1));  // Store the date value
                    strcpy(anniversary->date, token);

                    anniversary->UTC = isUTC;
                }

                // Assign to the vCard structure
                card->anniversary = anniversary;

                                
            }else if(strcasecmp(prop->name, "LANG") == 0){
                Property *lang = malloc(sizeof(Property));
                lang->name = malloc(sizeof(char)*(strlen(prop->name)+1));
                strcpy(lang->name, prop->name);
                lang->group = malloc(sizeof(char)*(strlen(prop->group)+1));
                strcpy(lang->group, prop->group);
                lang->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
                lang->values = initializeList(valueToString, deleteValue, compareValues);

                // Store the extracted value
                insertBack(lang->values, strdup(token));
                ListIterator iter = createIterator(prop->parameters);
                void* elem;
                while ((elem = nextElement(&iter)) != NULL) {
                    Parameter* original = (Parameter*)elem;
                    Parameter* valCopy = malloc(sizeof(Parameter));
                    valCopy->name = strdup(original->name);
                    valCopy->value = strdup(original->value);
                    insertBack(lang->parameters, valCopy);
                }
                insertBack(card->optionalProperties, lang);
                clearList(prop->parameters);
            }else if (strcasecmp(prop->name, "ORG") == 0){
                Property *org = malloc(sizeof(Property));
                org->name = malloc(sizeof(char)*(strlen(prop->name)+1));
                strcpy(org->name, prop->name);
                org->group = malloc(sizeof(char)*(strlen(prop->group)+1));
                strcpy(org->group, prop->group);
                org->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
                org->values = initializeList(valueToString, deleteValue, compareValues);

                // Store the extracted value
                insertBack(org->values, strdup(token));
                ListIterator iter = createIterator(prop->parameters);
                void* elem;
                while ((elem = nextElement(&iter)) != NULL) {
                    Parameter* original = (Parameter*)elem;
                    Parameter* valCopy = malloc(sizeof(Parameter));
                    valCopy->name = strdup(original->name);
                    valCopy->value = strdup(original->value);
                    insertBack(org->parameters, valCopy);
                }
                insertBack(card->optionalProperties, org);
                clearList(prop->parameters);
                
            }else if (strcasecmp(prop->name, "ADR") == 0){

                Property *adr = malloc(sizeof(Property));
                adr->name = malloc(sizeof(char)*(strlen(prop->name)+1));
                strcpy(adr->name, prop->name);
                adr->group = malloc(sizeof(char)*(strlen(prop->group)+1));
                strcpy(adr->group, prop->group);
                adr->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
                adr->values = initializeList(valueToString, deleteValue, compareValues);

                token = strtok(token, ";");
                while (token != NULL){
                    char *temp = malloc(sizeof(char)*(strlen(token)+1));
                    strcpy(temp, token);

                    insertBack(adr->values, temp);  // Store N value
                    token = strtok(NULL, ";");
                }
                // Store the extracted value
                ListIterator iter = createIterator(prop->parameters);
                void* elem;
                while ((elem = nextElement(&iter)) != NULL) {
                    Parameter* original = (Parameter*)elem;
                    Parameter* valCopy = malloc(sizeof(Parameter));
                    valCopy->name = strdup(original->name);
                    valCopy->value = strdup(original->value);
                    insertBack(adr->parameters, valCopy);
                }
                insertBack(card->optionalProperties, adr);
                clearList(prop->parameters);
                
            }else if (strcasecmp(prop->name, "TEL") == 0){

                Property *tel = malloc(sizeof(Property));
                tel->name = malloc(sizeof(char)*(strlen(prop->name)+1));
                strcpy(tel->name, prop->name);
                tel->group = malloc(sizeof(char)*(strlen(prop->group)+1));
                strcpy(tel->group, prop->group);
                tel->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
                tel->values = initializeList(valueToString, deleteValue, compareValues);

                token = strtok(token, ";");
                while (token != NULL){
                    char *temp = malloc(sizeof(char)*(strlen(token)+1));
                    strcpy(temp, token);

                    insertBack(tel->values, temp);  // Store N value
                    token = strtok(NULL, ";");
                }
                // Store the extracted value
                ListIterator iter = createIterator(prop->parameters);
                void* elem;
                while ((elem = nextElement(&iter)) != NULL) {
                    Parameter* original = (Parameter*)elem;
                    Parameter* valCopy = malloc(sizeof(Parameter));
                    valCopy->name = strdup(original->name);
                    valCopy->value = strdup(original->value);
                    insertBack(tel->parameters, valCopy);
                }
                insertBack(card->optionalProperties, tel);
                clearList(prop->parameters);
            }else if (strcasecmp(prop->name, "EMAIL") == 0){

                Property *email = malloc(sizeof(Property));
                email->name = malloc(sizeof(char)*(strlen(prop->name)+1));
                strcpy(email->name, prop->name);
                email->group = malloc(sizeof(char)*(strlen(prop->group)+1));
                strcpy(email->group, prop->group);
                email->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
                email->values = initializeList(valueToString, deleteValue, compareValues);

                token = strtok(token, ";");
                while (token != NULL){
                    char *temp = malloc(sizeof(char)*(strlen(token)+1));
                    strcpy(temp, token);

                    insertBack(email->values, temp);  // Store N value
                    token = strtok(NULL, ";");
                }
                // Store the extracted value
                ListIterator iter = createIterator(prop->parameters);
                void* elem;
                while ((elem = nextElement(&iter)) != NULL) {
                    Parameter* original = (Parameter*)elem;
                    Parameter* valCopy = malloc(sizeof(Parameter));
                    valCopy->name = strdup(original->name);
                    valCopy->value = strdup(original->value);
                    insertBack(email->parameters, valCopy);
                }
                insertBack(card->optionalProperties, email);
                clearList(prop->parameters);
            }else if (strcasecmp(prop->name, "GENDER") == 0){

                Property *gender = malloc(sizeof(Property));
                gender->name = malloc(sizeof(char)*(strlen(prop->name)+1));
                strcpy(gender->name, prop->name);
                gender->group = malloc(sizeof(char)*(strlen(prop->group)+1));
                strcpy(gender->group, prop->group);
                gender->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
                gender->values = initializeList(valueToString, deleteValue, compareValues);

                token = strtok(token, ";");
                while (token != NULL){
                    char *temp = malloc(sizeof(char)*(strlen(token)+1));
                    strcpy(temp, token);

                    insertBack(gender->values, temp);  // Store N value
                    token = strtok(NULL, ";");
                }
                // Store the extracted value
                ListIterator iter = createIterator(prop->parameters);
                void* elem;
                while ((elem = nextElement(&iter)) != NULL) {
                    Parameter* original = (Parameter*)elem;
                    Parameter* valCopy = malloc(sizeof(Parameter));
                    valCopy->name = strdup(original->name);
                    valCopy->value = strdup(original->value);
                    insertBack(gender->parameters, valCopy);
                }
                insertBack(card->optionalProperties, gender);
                clearList(prop->parameters);
            }
            else if (strcasecmp(prop->name, "GEO") == 0){

                Property *geo = malloc(sizeof(Property));
                geo->name = malloc(sizeof(char)*(strlen(prop->name)+1));
                strcpy(geo->name, prop->name);
                geo->group = malloc(sizeof(char)*(strlen(prop->group)+1));
                strcpy(geo->group, prop->group);
                geo->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
                geo->values = initializeList(valueToString, deleteValue, compareValues);

                token = strtok(token, ";");
                while (token != NULL){
                    char *temp = malloc(sizeof(char)*(strlen(token)+1));
                    strcpy(temp, token);

                    insertBack(geo->values, temp);  // Store N value
                    token = strtok(NULL, ";");
                }
                // Store the extracted value
                ListIterator iter = createIterator(prop->parameters);
                void* elem;
                while ((elem = nextElement(&iter)) != NULL) {
                    Parameter* original = (Parameter*)elem;
                    Parameter* valCopy = malloc(sizeof(Parameter));
                    valCopy->name = strdup(original->name);
                    valCopy->value = strdup(original->value);
                    insertBack(geo->parameters, valCopy);
                }
                insertBack(card->optionalProperties, geo);
                clearList(prop->parameters);
                
            }else if (strcasecmp(prop->name, "KEY") == 0){

                Property *key = malloc(sizeof(Property));
                key->name = malloc(sizeof(char)*(strlen(prop->name)+1));
                strcpy(key->name, prop->name);
                key->group = malloc(sizeof(char)*(strlen(prop->group)+1));
                strcpy(key->group, prop->group);
                key->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
                key->values = initializeList(valueToString, deleteValue, compareValues);

                token = strtok(token, ";");
                while (token != NULL){
                    char *temp = malloc(sizeof(char)*(strlen(token)+1));
                    strcpy(temp, token);

                    insertBack(key->values, temp);  // Store N value
                    token = strtok(NULL, ";");
                }
                // Store the extracted value
                ListIterator iter = createIterator(prop->parameters);
                void* elem;
                while ((elem = nextElement(&iter)) != NULL) {
                    Parameter* original = (Parameter*)elem;
                    Parameter* valCopy = malloc(sizeof(Parameter));
                    valCopy->name = strdup(original->name);
                    valCopy->value = strdup(original->value);
                    insertBack(key->parameters, valCopy);
                }
                insertBack(card->optionalProperties, key);
                clearList(prop->parameters);
            }else if (strcasecmp(prop->name, "TZ") == 0){

                Property *tz = malloc(sizeof(Property));
                tz->name = malloc(sizeof(char)*(strlen(prop->name)+1));
                strcpy(tz->name, prop->name);
                tz->group = malloc(sizeof(char)*(strlen(prop->group)+1));
                strcpy(tz->group, prop->group);
                tz->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
                tz->values = initializeList(valueToString, deleteValue, compareValues);

                token = strtok(token, ";");
                while (token != NULL){
                    char *temp = malloc(sizeof(char)*(strlen(token)+1));
                    strcpy(temp, token);

                    insertBack(tz->values, temp);
                    token = strtok(NULL, ";");
                }
                // Store the extracted value
                ListIterator iter = createIterator(prop->parameters);
                void* elem;
                while ((elem = nextElement(&iter)) != NULL) {
                    Parameter* original = (Parameter*)elem;
                    Parameter* valCopy = malloc(sizeof(Parameter));
                    valCopy->name = strdup(original->name);
                    valCopy->value = strdup(original->value);
                    insertBack(tz->parameters, valCopy);
                }
                insertBack(card->optionalProperties, tz);
                clearList(prop->parameters);
                
            }else if (strcasecmp(prop->name, "URL") == 0){

                Property *url = malloc(sizeof(Property));
                url->name = malloc(sizeof(char)*(strlen(prop->name)+1));
                strcpy(url->name, prop->name);
                url->group = malloc(sizeof(char)*(strlen(prop->group)+1));
                strcpy(url->group, prop->group);
                url->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
                url->values = initializeList(valueToString, deleteValue, compareValues);

                token = strtok(token, ";");
                while (token != NULL){
                    char *temp = malloc(sizeof(char)*(strlen(token)+1));
                    strcpy(temp, token);

                    insertBack(url->values, temp);
                    token = strtok(NULL, ";");
                }
                // Store the extracted value
                ListIterator iter = createIterator(prop->parameters);
                void* elem;
                while ((elem = nextElement(&iter)) != NULL) {
                    Parameter* original = (Parameter*)elem;
                    Parameter* valCopy = malloc(sizeof(Parameter));
                    valCopy->name = strdup(original->name);
                    valCopy->value = strdup(original->value);
                    insertBack(url->parameters, valCopy);
                }
                insertBack(card->optionalProperties, url);
                clearList(prop->parameters);
                
            }else{
                if(strcasecmp(prop->name, "FN") == 0 && fnFilled == true){
                    deleteProperty(prop);
                    return INV_PROP;
                }else if (strcasecmp(prop->name, "BDAY") == 0 && bdayFilled == true){
                    deleteProperty(prop);
                    return INV_DT;
                }else if (strcasecmp(prop->name, "ANNIVERSARY") == 0 && annFilled == true){
                    deleteProperty(prop);
                    return INV_DT;
                }
            }

        }
    }
    deleteProperty(prop);
    return INV_CARD;
}


